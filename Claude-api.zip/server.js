const express = require('express');
const { Readable } = require('stream');
const fs = require('fs');
const path = require('path');

const adminApp = express();
const proxyApp = express();

const DATA_DIR = path.join(__dirname, 'data');
const KEYS_FILE = path.join(DATA_DIR, 'keys.json');

// Garante que a pasta data existe (para o volume Docker)
if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
}

let keys = [];

// Carrega as chaves do disco
if (fs.existsSync(KEYS_FILE)) {
    try {
        keys = JSON.parse(fs.readFileSync(KEYS_FILE, 'utf8'));
    } catch (e) {
        console.error("Erro ao carregar chaves:", e);
    }
}

function saveKeys() {
    fs.writeFileSync(KEYS_FILE, JSON.stringify(keys, null, 2));
}

// ==========================================
// 1. SERVIDOR ADMIN (Porta 88)
// ==========================================
adminApp.use(express.json());
adminApp.use(express.static(path.join(__dirname, 'public')));

adminApp.get('/api/keys', (req, res) => res.json(keys));

adminApp.post('/api/keys', (req, res) => {
    const { key, role, name } = req.body;
    const newKey = { id: Date.now().toString(), key, role, name };
    keys.push(newKey);
    saveKeys();
    res.json(newKey);
});

adminApp.delete('/api/keys/:id', (req, res) => {
    keys = keys.filter(k => k.id !== req.params.id);
    saveKeys();
    res.json({ success: true });
});

adminApp.listen(88, () => {
    console.log('✅ Painel Administrativo rodando na porta 88');
});


// ==========================================
// 2. SERVIDOR PROXY (Porta 11431)
// ==========================================
proxyApp.use((req, res, next) => {
    // Configura o CORS básico pro proxy caso seja chamado por browser
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    res.header('Access-Control-Allow-Headers', '*');
    if (req.method === 'OPTIONS') return res.sendStatus(200);
    next();
});
proxyApp.use(express.raw({ type: '*/*', limit: '50mb' })); // Permite ler qualquer body (json, multipart, etc) como Buffer

let subKeyIndex = 0;
let allKeyIndex = 0;

proxyApp.all('/v1/*', async (req, res) => {
    const agentType = (req.headers['x-agent-type'] || 'none').toLowerCase();
    
    // Categoriza chaves
    const mainKeys = keys.filter(k => k.role === 'main' || k.role === 'all');
    const subKeys = keys.filter(k => k.role === 'sub' || k.role === 'all');
    const allKeys = keys;

    if (allKeys.length === 0) {
        return res.status(500).json({ error: "Nenhuma chave configurada no proxy. Acesse a porta 88 para adicionar." });
    }

    // Define a ordem de tentativa (Pipeline)
    let pipeline = [];
    if (agentType === 'main' && mainKeys.length > 0) {
        pipeline = [...mainKeys, ...subKeys]; 
    } else if (agentType === 'sub' && subKeys.length > 0) {
        // Round Robin para os Sub-Agentes
        const startIdx = subKeyIndex % subKeys.length;
        subKeyIndex++;
        pipeline = [...subKeys.slice(startIdx), ...subKeys.slice(0, startIdx), ...mainKeys];
    } else {
        // Balanceamento Geral
        const startIdx = allKeyIndex % allKeys.length;
        allKeyIndex++;
        pipeline = [...allKeys.slice(startIdx), ...allKeys.slice(0, startIdx)];
    }

    // Remove duplicatas mantendo a ordem do array
    pipeline = [...new Map(pipeline.map(item => [item.key, item])).values()];

    // Constrói a URL destino repassando a rota (ex: /v1/chat/completions)
    const targetUrl = `https://integrate.api.nvidia.com${req.url}`;

    // Tenta enviar a requisição passando pela pipeline de chaves
    for (const keyObj of pipeline) {
        const controller = new AbortController();
        const onClientDisconnect = () => controller.abort();
        req.on('close', onClientDisconnect);

        try {
            const fetchOptions = {
                method: req.method,
                headers: {
                    'Authorization': `Bearer ${keyObj.key}`,
                    'Content-Type': req.headers['content-type'] || 'application/json',
                    'Accept': req.headers['accept'] || '*/*'
                }
            };

            // GET e HEAD não podem ter body
            if (req.method !== 'GET' && req.method !== 'HEAD' && req.body) {
                if (Buffer.isBuffer(req.body) && req.body.length > 0) {
                    fetchOptions.body = req.body;
                } else if (!Buffer.isBuffer(req.body) && Object.keys(req.body).length > 0) {
                    fetchOptions.body = JSON.stringify(req.body);
                }
            }

            fetchOptions.signal = controller.signal;
            const fetchRes = await fetch(targetUrl, fetchOptions);
            req.removeListener('close', onClientDisconnect);

            // Rate Limit: ignora e tenta a próxima chave do pipeline
            if (fetchRes.status === 429) {
                console.warn(`[Proxy ⚠️] Rate limit na chave '${keyObj.name}'. Realizando fallback...`);
                continue; 
            }

            // Repassa os headers pro cliente (exceto os que quebram o fluxo no express)
            const excludeHeaders = ['content-encoding', 'content-length', 'connection'];
            fetchRes.headers.forEach((val, key) => {
                if (!excludeHeaders.includes(key.toLowerCase())) {
                    res.setHeader(key, val);
                }
            });

            res.status(fetchRes.status);

            // Suporta streaming (Web Streams para Node Streams)
            if (fetchRes.body) {
                const stream = Readable.fromWeb(fetchRes.body);
                stream.pipe(res);
                stream.on('error', (err) => {
                    console.error(`[Proxy ❌] Erro no stream com a chave '${keyObj.name}':`, err.message);
                    if (!res.headersSent) res.status(500).end();
                });
                return;
            } else {
                return res.end();
            }

        } catch (error) {
            req.removeListener('close', onClientDisconnect);
            if (error.name === 'AbortError') {
                console.warn(`[Proxy ⚠️] Cliente fechou a conexão (AbortError).`);
                return res.end();
            }
            console.error(`[Proxy ❌] Falha de rede com a chave '${keyObj.name}':`, error.message);
            continue; // Tenta a próxima chave
        }
    }

    // Se chegou aqui, todas as chaves falharam (estão em Rate Limit)
    console.error(`[Proxy 🛑] Todas as chaves do pool atingiram o Rate Limit.`);
    res.status(429).json({ error: "Rate limit atingido em todas as chaves da Nvidia NIM disponíveis." });
});

proxyApp.listen(11431, () => {
    console.log('✅ Proxy NVIDIA NIM rodando na porta 11431');
});